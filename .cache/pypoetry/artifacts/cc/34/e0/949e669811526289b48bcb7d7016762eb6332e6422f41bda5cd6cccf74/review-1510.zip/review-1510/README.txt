`upload.py` from rietveld project repackaged for PyPI
to make code review uploads easier.

To update script, run `refresh.py`.