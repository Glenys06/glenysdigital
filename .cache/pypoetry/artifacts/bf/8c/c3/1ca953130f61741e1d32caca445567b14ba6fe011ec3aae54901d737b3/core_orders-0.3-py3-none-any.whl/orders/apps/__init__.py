from .orders.all_orders_list import AllOrderAdminWidget
from .orders.orders_list import OrderAdminWidget